#!/usr/bin/env python3
"""Repeatable integrity checks for the Stranded research bundle (not an iOS build)."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
for name in ["CHAPTER_RECORDS.json","CHAPTER_STATISTICS.json","PNG_ASSET_MANIFEST.json","EMBEDDED_PNG_REPORT.json"]:
 p=ROOT/"Research"/name
 if not p.exists(): errors.append(f"missing {p}"); continue
 try: json.loads(p.read_text())
 except Exception as e: errors.append(f"invalid JSON {name}: {e}")
chap=json.loads((ROOT/"Research/CHAPTER_RECORDS.json").read_text())
for c in chap:
 if c.get("trailing_bytes",0)!=0: errors.append(f"trailing bytes in {c.get('file')}")
 if c.get("bytes_consumed") != c.get("bytes"): errors.append(f"consumption mismatch in {c.get('file')}")
for p in [ROOT/"StrandedIOS/StrandedApp.swift",ROOT/"StrandedIOS/StrandedFrameDriver.swift",ROOT/".github/workflows/build-ipa.yml"]:
 if not p.exists(): errors.append(f"missing project file: {p.relative_to(ROOT)}")
if errors:
 print("FAIL"); print("\n".join(errors)); sys.exit(1)
print(f"PASS: {len(chap)} chapter records validated; JSON and starter files present.")
print("NOTE: this does not compile Swift or prove gameplay/FPS.")
