#!/usr/bin/env python3
"""Extract the indexed payloads from Stranded's Java ME PAK archives.

Format: u16be directory_end, u16be entry_count, then repeated
u16be UTF-8/Latin-1 name length, name bytes, u32be relative payload offset,
u32be payload size. Payload offsets are relative to directory_end.
"""
from pathlib import Path
import argparse, hashlib, json, struct, zipfile

def extract(data: bytes, output: Path):
    if len(data) < 4:
        raise ValueError('Archive too short')
    directory_end, count = struct.unpack_from('>HH', data, 0)
    pos = 4
    entries = []
    for index in range(count):
        if pos + 2 > len(data): raise ValueError(f'entry {index}: missing name length')
        name_len = struct.unpack_from('>H', data, pos)[0]; pos += 2
        if pos + name_len + 8 > len(data): raise ValueError(f'entry {index}: truncated directory record')
        name = data[pos:pos+name_len].decode('latin1'); pos += name_len
        offset, size = struct.unpack_from('>II', data, pos); pos += 8
        if not name or '/' in name or '\\' in name or name in ('.', '..'):
            raise ValueError(f'unsafe entry name: {name!r}')
        start = directory_end + offset
        end = start + size
        if start < directory_end or end > len(data):
            raise ValueError(f'{name}: payload range [{start},{end}) outside archive')
        entries.append((name, offset, size, data[start:end]))
    if pos != directory_end:
        raise ValueError(f'directory parsed to {pos}, header declares {directory_end}')
    output.mkdir(parents=True, exist_ok=True)
    rows=[]
    for name, offset, size, payload in entries:
        (output/name).write_bytes(payload)
        rows.append({'name':name,'offset':offset,'size':size,'sha256':hashlib.sha256(payload).hexdigest(),'signature':payload[:8].hex(' ')})
    (output/'INDEX.json').write_text(json.dumps(rows, indent=2, ensure_ascii=False)+'\n')
    return {'directory_end':directory_end,'entry_count':count,'directory_parsed_bytes':pos,'payload_bytes':sum(e[2] for e in entries),'archive_size':len(data),'entries':rows}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('jar',type=Path)
    ap.add_argument('--out',type=Path,default=Path('Resources/GameData'))
    args=ap.parse_args()
    reports=[]
    with zipfile.ZipFile(args.jar) as z:
        for pak in ('res_0.pak','res_1.pak'):
            reports.append({'archive':pak,**extract(z.read(pak),args.out/pak.removesuffix('.pak'))})
    report_path=args.out.parent/'Research'/'PAK_EXTRACTION_REPORT.json'
    report_path.parent.mkdir(parents=True,exist_ok=True)
    report_path.write_text(json.dumps(reports,indent=2,ensure_ascii=False)+'\n')
    print(f'Extracted {sum(x["entry_count"] for x in reports)} files; report: {report_path}')
if __name__=='__main__': main()
