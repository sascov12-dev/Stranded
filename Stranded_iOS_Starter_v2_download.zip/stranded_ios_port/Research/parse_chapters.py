#!/usr/bin/env python3
"""Parse Stranded chapter*.dat records using the read order recovered from JVM bytecode."""
from pathlib import Path
import struct, json, sys

def parse(path):
    data=Path(path).read_bytes(); pos=0
    def take(n):
        nonlocal pos
        if n < 0 or pos+n > len(data): raise ValueError(f"invalid length {n} at offset {pos}")
        out=data[pos:pos+n]; pos+=n; return out
    count=struct.unpack('>b',take(1))[0]
    if count<0: raise ValueError(f"negative record count: {count}")
    records=[]
    for index in range(count):
        rid=struct.unpack('>h',take(2))[0]
        typ=struct.unpack('>b',take(1))[0]
        size=struct.unpack('>h',take(2))[0]
        payload=take(size)
        records.append({'index':index,'id':rid,'type':typ,'payload_length':size,'payload_hex':payload.hex()})
    if pos != len(data): raise ValueError(f"{len(data)-pos} trailing bytes")
    return {'file':Path(path).name,'bytes':len(data),'records':count,'bytes_consumed':pos,'trailing_bytes':len(data)-pos,'entries':records}

if __name__=='__main__':
    paths=[Path(p) for p in sys.argv[1:]] or sorted(Path('Resources/GameData/res_0').glob('chapter*.dat'))
    result=[parse(p) for p in paths]
    print(json.dumps(result,indent=2))
