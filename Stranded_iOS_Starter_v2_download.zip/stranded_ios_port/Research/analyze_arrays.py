#!/usr/bin/env python3
"""Parse arrays.bin using the exact sequence of typed-array reads in i.e()."""
from pathlib import Path
import json, struct, sys

def parse(path):
    data=Path(path).read_bytes(); pos=0; arrays=[]
    # Mirrors i.e(): short[], five byte[][], nineteen byte[], three short[],
    # byte[][], byte[], byte[][], eleven byte[].
    signature=['S']+['BB']*5+['B']*19+['S']*3+['BB','B','BB']+['B']*11
    def take(n):
        nonlocal pos
        if pos+n>len(data): raise ValueError(f'truncated at offset {pos}, need {n} bytes')
        b=data[pos:pos+n];pos+=n;return b
    for idx,kind in enumerate(signature):
        if kind=='S':
            n=struct.unpack('>h',take(2))[0]
            if n<0: raise ValueError(f'array {idx}: negative short[] length {n}')
            vals=list(struct.unpack('>'+('h'*n),take(2*n))) if n else []
            arrays.append({'index':idx,'type':'short[]','count':n,'values':vals})
        elif kind=='B':
            n=struct.unpack('>b',take(1))[0]
            if n<0: raise ValueError(f'array {idx}: negative byte[] length {n}')
            vals=list(struct.unpack('>'+('b'*n),take(n))) if n else []
            arrays.append({'index':idx,'type':'byte[]','count':n,'values':vals})
        else:
            n=struct.unpack('>b',take(1))[0]
            if n<0: raise ValueError(f'array {idx}: negative byte[][] length {n}')
            rows=[]
            for _ in range(n):
                m=struct.unpack('>b',take(1))[0]
                if m<0: raise ValueError(f'array {idx}: negative row length {m}')
                vals=list(struct.unpack('>'+('b'*m),take(m))) if m else []
                rows.append(vals)
            arrays.append({'index':idx,'type':'byte[][]','count':n,'row_lengths':[len(r) for r in rows],'values':rows})
    if pos!=len(data): raise ValueError(f'parsed {pos} of {len(data)} bytes; {len(data)-pos} trailing')
    return {'source':Path(path).name,'bytes':len(data),'arrays_parsed':len(arrays),'bytes_consumed':pos,'trailing_bytes':len(data)-pos,'arrays':arrays}
if __name__=='__main__':
    p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('Resources/GameData/res_0/arrays.bin')
    result=parse(p)
    out=p.parent/'arrays_decoded.json'
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(f'{result["source"]}: parsed {result["arrays_parsed"]} arrays, {result["bytes_consumed"]}/{result["bytes"]} bytes; wrote {out}')
