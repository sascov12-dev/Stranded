import UIKit
import QuartzCore

/// Prototype only: rendering is scheduled by iOS at display refresh rate,
/// while simulation advances in fixed steps. Original game's 50 ms loop is
/// provisional and must be validated against actual gameplay before use.
final class StrandedFrameDriver: NSObject {
    private var displayLink: CADisplayLink?
    private var previousTimestamp: CFTimeInterval = 0
    private var accumulator: TimeInterval = 0

    /// Bytecode suggests a nominal 50 ms loop (~20 simulation updates/s).
    /// Do not treat this as a confirmed gameplay speed until movement/timers
    /// are measured in the original game.
    private let fixedStep: TimeInterval = 0.050
    private let maxFrameDelta: TimeInterval = 0.100

    /// Connect these closures to the port's simulation and renderer.
    var updateSimulation: ((TimeInterval) -> Void)?
    var renderFrame: ((CGFloat) -> Void)?

    func start() {
        guard displayLink == nil else { return }
        previousTimestamp = 0
        accumulator = 0
        let link = CADisplayLink(target: self, selector: #selector(frame(_:)))
        link.preferredFramesPerSecond = 60
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    func stop() {
        displayLink?.invalidate()
        displayLink = nil
        previousTimestamp = 0
        accumulator = 0
    }

    @objc private func frame(_ link: CADisplayLink) {
        if previousTimestamp == 0 {
            previousTimestamp = link.timestamp
            renderFrame?(0)
            return
        }

        let rawDelta = link.timestamp - previousTimestamp
        previousTimestamp = link.timestamp
        let delta = min(max(rawDelta, 0), maxFrameDelta)
        accumulator += delta

        // Keep the original simulation cadence separate from drawing cadence.
        while accumulator >= fixedStep {
            updateSimulation?(fixedStep)
            accumulator -= fixedStep
        }

        // Fraction for visual interpolation between previous/current states.
        renderFrame?(CGFloat(accumulator / fixedStep))
    }
}
