import SwiftUI
import UIKit

@main
struct StrandedApp: App {
    var body: some Scene {
        WindowGroup { PortHomeView() }
    }
}

private enum PortPalette {
    static let background = Color(red: 0.035, green: 0.055, blue: 0.045)
    static let accent = Color(red: 0.93, green: 0.72, blue: 0.12)
}

struct PortHomeView: View {
    @State private var showGallery = false
    @State private var showSandbox = false

    var body: some View {
        ZStack {
            PortPalette.background.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 18) {
                    if let splash = bundledImage("sp") {
                        Image(uiImage: splash)
                            .resizable()
                            .interpolation(.none)
                            .aspectRatio(contentMode: .fit)
                            .frame(maxWidth: 310, maxHeight: 390)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(.white.opacity(0.12)))
                    }
                    Text("STRANDED")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .tracking(5)
                        .foregroundStyle(.white)
                    Text("ПРОТОТИП ПОРТА ДЛЯ iOS")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.5)
                        .foregroundStyle(PortPalette.accent)
                    Text("Оригинальные ресурсы подключены. Игровая логика ещё переносится — это пока не играбельная версия.")
                        .font(.system(size: 14))
                        .foregroundStyle(.white.opacity(0.75))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)
                    Button { showSandbox = true } label: {
                        Text("ОТКРЫТЬ ТЕСТ УПРАВЛЕНИЯ")
                            .font(.system(size: 13, weight: .bold, design: .monospaced))
                            .tracking(1)
                            .foregroundStyle(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(Color(red: 0.34, green: 0.82, blue: 0.62))
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    .padding(.horizontal, 28)
                    Button { showGallery = true } label: {
                        Text("ПРОВЕРИТЬ РЕСУРСЫ")
                            .font(.system(size: 13, weight: .bold, design: .monospaced))
                            .tracking(1)
                            .foregroundStyle(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(PortPalette.accent)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    .padding(.horizontal, 28)
                    Text("ЦЕЛЬ: 60 FPS • ОРИГИНАЛЬНЫЙ ГЕЙМПЛЕЙ")
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.5))
                        .padding(.top, 4)
                }
                .padding(.vertical, 22)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showGallery) { ResourceGalleryView() }
        .fullScreenCover(isPresented: $showSandbox) { MovementSandboxView() }
    }
}

struct ResourceGalleryView: View {
    @Environment(\.dismiss) private var dismiss
    private let images = ["ch00a", "ch00b", "ch01", "ch02", "ch03", "ch04", "ch05", "ch06", "mb", "sp", "i"]
    private let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(images, id: \.self) { name in
                        VStack(spacing: 7) {
                            if let image = bundledImage(name) {
                                Image(uiImage: image)
                                    .resizable()
                                    .interpolation(.none)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 170)
                                    .background(Color.white.opacity(0.05))
                                    .clipShape(RoundedRectangle(cornerRadius: 6))
                            } else {
                                RoundedRectangle(cornerRadius: 6).fill(.red.opacity(0.15))
                                    .frame(height: 170)
                                    .overlay(Text("Не найдено").foregroundStyle(.red))
                            }
                            Text(name + ".png")
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundStyle(.white.opacity(0.8))
                        }
                    }
                }
                .padding()
            }
            .background(PortPalette.background)
            .navigationTitle("Ресурсы игры")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Готово") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
    }
}

private func bundledImage(_ name: String) -> UIImage? {
    // XcodeGen may preserve the Resources directory in the app bundle.
    // Try both the bundle root and the Resources subdirectory.
    let rootURL = Bundle.main.url(forResource: name, withExtension: "png")
    let resourcesURL = Bundle.main.url(forResource: name, withExtension: "png", subdirectory: "Resources")
    guard let url = rootURL ?? resourcesURL else { return nil }
    return UIImage(contentsOfFile: url.path)
}
