import SwiftUI
import SpriteKit

/// Expanded playable systems prototype. It is still a reconstruction sandbox, not the original game logic.
struct MovementSandboxView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var scene = IslandSandboxScene(size: CGSize(width: 390, height: 700))

    var body: some View {
        ZStack(alignment: .top) {
            SpriteView(scene: scene, options: [.ignoresSiblingOrder]).ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    Button("‹ Назад") { dismiss() }
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .padding(.horizontal, 13).padding(.vertical, 9)
                        .background(.black.opacity(0.72)).clipShape(Capsule())
                    Spacer()
                    Text("ОСТРОВ • ПРОТОТИП")
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .padding(.horizontal, 11).padding(.vertical, 9)
                        .background(.black.opacity(0.72)).clipShape(Capsule())
                }.padding(.horizontal, 14).padding(.top, 10)
                Spacer()
                HStack(alignment: .bottom) {
                    VStack(spacing: 7) {
                        HStack(spacing: 7) {
                            holdButton("◀", dx: -1, dy: 0)
                            VStack(spacing: 7) {
                                holdButton("▲", dx: 0, dy: 1)
                                holdButton("▼", dx: 0, dy: -1)
                            }
                            holdButton("▶", dx: 1, dy: 0)
                        }
                        Text("УДЕРЖИВАЙ ДЛЯ ДВИЖЕНИЯ")
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    Spacer(minLength: 8)
                    VStack(spacing: 9) {
                        Button { scene.interact() } label: {
                            VStack(spacing: 3) { Image(systemName: "hand.tap.fill"); Text("СОБРАТЬ") }
                                .font(.system(size: 10, weight: .black, design: .monospaced))
                                .frame(width: 68, height: 58)
                                .background(Color(red: 0.74, green: 0.52, blue: 0.18).opacity(0.95))
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                        }.buttonStyle(.plain)
                        Button { scene.resetPlayer() } label: {
                            Image(systemName: "arrow.counterclockwise")
                                .font(.system(size: 15, weight: .bold))
                                .frame(width: 44, height: 38).background(.black.opacity(0.72)).clipShape(Capsule())
                        }.buttonStyle(.plain)
                    }
                }.foregroundStyle(.white).padding(.horizontal, 15).padding(.bottom, 25)
            }
        }
        .statusBarHidden().preferredColorScheme(.dark)
    }

    private func holdButton(_ title: String, dx: CGFloat, dy: CGFloat) -> some View {
        Button { scene.nudge(dx: dx, dy: dy) } label: {
            Text(title).font(.system(size: 19, weight: .black))
                .frame(width: 43, height: 43).background(.black.opacity(0.76)).clipShape(Circle())
                .overlay(Circle().stroke(.white.opacity(0.28), lineWidth: 1))
        }.buttonStyle(.plain)
        // Repeated taps are deliberate in this prototype; the movement engine is fixed-step and frame-independent.
    }
}

final class IslandSandboxScene: SKScene {
    private let player = SKNode()
    private let cameraNode = SKCameraNode()
    private var initialPosition = CGPoint.zero
    private var lastUpdate: TimeInterval = 0
    private var moveVector = CGVector.zero
    private var pickups: [SKNode] = []
    private var collected = 0
    private var stamina: CGFloat = 100
    private var elapsed: TimeInterval = 0
    private var dayClock: CGFloat = 0
    private let worldSize = CGSize(width: 1800, height: 1800)
    private let hud = SKLabelNode(fontNamed: "Menlo-Bold")
    private let message = SKLabelNode(fontNamed: "Menlo-Bold")

    override func didMove(to view: SKView) {
        scaleMode = .resizeFill
        anchorPoint = CGPoint(x: 0.5, y: 0.5)
        backgroundColor = SKColor(red: 0.035, green: 0.20, blue: 0.23, alpha: 1)
        camera = cameraNode
        addChild(cameraNode)
        buildWorld()
        buildPlayer()
        configureHUD()
    }

    private func buildWorld() {
        // Repeating original game tiles; full chapter/map decoding remains a separate porting task.
        let tileNames = ["island_tile", "ground_tile"]
        let tileSize: CGFloat = 32
        let cols = Int(worldSize.width / tileSize)
        let rows = Int(worldSize.height / tileSize)
        for row in 0..<rows {
            for col in 0..<cols {
                let tile = SKSpriteNode(imageNamed: tileNames[(row + col) % tileNames.count])
                tile.size = CGSize(width: tileSize, height: tileSize)
                tile.position = CGPoint(x: CGFloat(col) * tileSize - worldSize.width / 2,
                                        y: CGFloat(row) * tileSize - worldSize.height / 2)
                tile.zPosition = 0
                addChild(tile)
            }
        }
        // The coastline and scattered vegetation make a large navigable test map.
        let island = SKShapeNode(ellipseOf: CGSize(width: 1450, height: 1320))
        island.fillColor = SKColor(red: 0.69, green: 0.59, blue: 0.34, alpha: 0.94)
        island.strokeColor = SKColor(red: 0.27, green: 0.42, blue: 0.25, alpha: 1)
        island.lineWidth = 32; island.zPosition = 1; addChild(island)
        for i in 0..<95 {
            let x = CGFloat((i * 173) % 1260) - 630
            let y = CGFloat((i * 271) % 1120) - 560
            let plant = SKSpriteNode(imageNamed: "plant_tile")
            plant.size = CGSize(width: 20, height: 23)
            plant.position = CGPoint(x: x, y: y); plant.zPosition = 2
            addChild(plant)
        }
        // Collectible wood/food markers are prototype objects, not claimed to be original item definitions.
        for i in 0..<22 {
            let node = SKNode()
            node.name = "pickup_\(i)"
            let glow = SKShapeNode(circleOfRadius: 10)
            glow.fillColor = SKColor(red: 0.98, green: 0.78, blue: 0.23, alpha: 0.25)
            glow.strokeColor = .clear; node.addChild(glow)
            let item = SKShapeNode(rectOf: CGSize(width: 9, height: 12), cornerRadius: 2)
            item.fillColor = i % 2 == 0 ? .systemGreen : .systemOrange
            item.strokeColor = .white.withAlphaComponent(0.8); item.lineWidth = 1
            item.position = CGPoint(x: 0, y: 1); node.addChild(item)
            node.position = CGPoint(x: CGFloat((i * 239) % 1120) - 560,
                                    y: CGFloat((i * 317) % 980) - 490)
            node.zPosition = 4; addChild(node); pickups.append(node)
        }
        // World boundaries.
        let boundary = SKShapeNode(rectOf: worldSize)
        boundary.strokeColor = .white.withAlphaComponent(0.25); boundary.lineWidth = 4
        boundary.fillColor = .clear; boundary.zPosition = 8; addChild(boundary)
    }

    private func buildPlayer() {
        let shadow = SKShapeNode(ellipseOf: CGSize(width: 24, height: 8))
        shadow.fillColor = .black.withAlphaComponent(0.32); shadow.strokeColor = .clear
        shadow.position = CGPoint(x: 0, y: -13); player.addChild(shadow)
        // Until the original sprite-sheet frame layout is confirmed, use a clear placeholder silhouette.
        let body = SKShapeNode(rectOf: CGSize(width: 13, height: 22), cornerRadius: 3)
        body.fillColor = SKColor(red: 0.19, green: 0.22, blue: 0.17, alpha: 1)
        body.strokeColor = .white.withAlphaComponent(0.8); body.lineWidth = 1
        body.position = CGPoint(x: 0, y: -1); player.addChild(body)
        let head = SKShapeNode(ellipseOf: CGSize(width: 13, height: 13))
        head.fillColor = SKColor(red: 0.77, green: 0.58, blue: 0.38, alpha: 1)
        head.strokeColor = .black.withAlphaComponent(0.5); head.position = CGPoint(x: 0, y: 12)
        player.addChild(head); player.zPosition = 10; addChild(player)
        initialPosition = .zero; player.position = initialPosition
    }

    private func configureHUD() {
        hud.fontSize = 10; hud.fontColor = .white; hud.horizontalAlignmentMode = .left
        hud.verticalAlignmentMode = .top; hud.position = CGPoint(x: -size.width / 2 + 14, y: size.height / 2 - 52)
        hud.zPosition = 100; cameraNode.addChild(hud)
        message.fontSize = 10; message.fontColor = .white; message.horizontalAlignmentMode = .center
        message.position = CGPoint(x: 0, y: -size.height / 2 + 105); message.zPosition = 100
        cameraNode.addChild(message)
        updateHUD()
    }

    func nudge(dx: CGFloat, dy: CGFloat) {
        let len = max(1, sqrt(dx * dx + dy * dy))
        moveVector = CGVector(dx: dx / len, dy: dy / len)
        let step: CGFloat = 28
        let proposed = CGPoint(x: player.position.x + moveVector.dx * step,
                               y: player.position.y + moveVector.dy * step)
        let limitX = worldSize.width / 2 - 24, limitY = worldSize.height / 2 - 24
        player.position = CGPoint(x: min(limitX, max(-limitX, proposed.x)),
                                  y: min(limitY, max(-limitY, proposed.y)))
        cameraNode.position = player.position
        stamina = max(0, stamina - 0.35)
        updateHUD()
    }

    func interact() {
        guard let nearest = pickups.filter({ $0.parent != nil }).min(by: {
            distance($0.position, player.position) < distance($1.position, player.position)
        }) else { message.text = "РЯДОМ НЕТ ПРЕДМЕТОВ"; return }
        if distance(nearest.position, player.position) <= 82 {
            nearest.removeFromParent(); collected += 1
            stamina = min(100, stamina + 4)
            message.text = "ПРЕДМЕТ СОБРАН • +1 • ЭНЕРГИЯ +4"
        } else {
            message.text = "ПОДОЙДИ БЛИЖЕ К ПРЕДМЕТУ"
        }
        updateHUD()
    }

    func resetPlayer() {
        player.removeAllActions(); player.position = initialPosition
        cameraNode.position = initialPosition; stamina = 100; collected = 0
        // Reset collectible markers for repeatable testing.
        for node in pickups where node.parent == nil { addChild(node) }
        message.text = "ТЕСТ СБРОШЕН"; updateHUD()
    }

    override func update(_ currentTime: TimeInterval) {
        if lastUpdate > 0 {
            let dt = min(0.05, currentTime - lastUpdate)
            elapsed += dt; dayClock += CGFloat(dt) * 0.012
            if elapsed >= 0.25 { updateHUD(); elapsed = 0 }
        }
        lastUpdate = currentTime
    }

    private func updateHUD() {
        let bar = String(repeating: "▰", count: max(0, min(10, Int(stamina / 10))))
        let empty = String(repeating: "▱", count: max(0, 10 - Int(stamina / 10)))
        hud.text = "ЭНЕРГИЯ [\(bar)\(empty)]  \(Int(stamina))%\nСОБРАНО: \(collected)   ОБЪЕКТЫ: \(pickups.filter { $0.parent != nil }.count)\nМИР: \(Int(dayClock * 100) % 100)% • ТЕСТОВАЯ КАРТА"
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        let dx = a.x - b.x, dy = a.y - b.y
        return sqrt(dx * dx + dy * dy)
    }
}
