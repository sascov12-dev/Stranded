import SwiftUI
import UIKit

@main
struct StrandedApp: App {
    var body: some Scene {
        WindowGroup { PortHomeView() }
    }
}

private enum MenuPalette {
    static let ink = Color(red: 0.035, green: 0.055, blue: 0.055)
    static let panel = Color.black.opacity(0.62)
    static let gold = Color(red: 0.93, green: 0.72, blue: 0.12)
    static let pale = Color(red: 0.91, green: 0.92, blue: 0.87)
}

private enum MenuPage: String, Identifiable {
    case settings, controls, about
    var id: String { rawValue }
}

struct PortHomeView: View {
    @AppStorage("stranded.musicEnabled") private var musicEnabled = true
    @AppStorage("stranded.soundEnabled") private var soundEnabled = true
    @AppStorage("stranded.language") private var language = "Русский"
    @AppStorage("stranded.controlMode") private var controlMode = "Экранные кнопки"
    @AppStorage("stranded.hasSave") private var hasSave = false
    @State private var page: MenuPage?
    @State private var pendingAction: String?
    @State private var showResourceGallery = false
    @State private var showMovementTest = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                menuBackground
                LinearGradient(colors: [.black.opacity(0.22), .black.opacity(0.64)], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                VStack(spacing: 0) {
                    Spacer(minLength: 8)
                    VStack(spacing: 7) {
                        Text("STRANDED")
                            .font(.system(size: min(geo.size.width * 0.105, 40), weight: .black, design: .serif))
                            .tracking(5)
                            .foregroundStyle(MenuPalette.pale)
                            .shadow(color: .black, radius: 8, y: 3)
                        Rectangle().fill(MenuPalette.gold).frame(width: 112, height: 2)
                        Text("ОСТРОВ • ВЫЖИВАНИЕ")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .tracking(2.2)
                            .foregroundStyle(MenuPalette.gold)
                    }
                    .padding(.bottom, 26)

                    VStack(spacing: 10) {
                        menuButton("НОВАЯ ИГРА", subtitle: "Начать приключение", prominent: true) {
                            pendingAction = "Новая игра"
                        }
                        menuButton("ПРОДОЛЖИТЬ", subtitle: hasSave ? "Продолжить сохранение" : "Сохранение пока не найдено", disabled: !hasSave) {
                            pendingAction = "Продолжить"
                        }
                        menuButton("НАСТРОЙКИ", subtitle: "Звук, язык и управление") { page = .settings }
                        menuButton("УПРАВЛЕНИЕ", subtitle: "Как играть на iPhone") { page = .controls }
                        menuButton("ОБ ИГРЕ", subtitle: "Stranded • Java ME → iOS") { page = .about }
                    }
                    .padding(.horizontal, min(geo.size.width * 0.105, 38))
                    Spacer(minLength: 18)
                    HStack(spacing: 12) {
                        Button { showResourceGallery = true } label: {
                            Label("РЕСУРСЫ", systemImage: "photo.on.rectangle.angled")
                                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        }
                        Text("•").foregroundStyle(MenuPalette.gold.opacity(0.8))
                        Button { showMovementTest = true } label: {
                            Label("ТЕСТ УПРАВЛЕНИЯ", systemImage: "gamecontroller")
                                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        }
                    }
                    .foregroundStyle(.white.opacity(0.78))
                    .padding(.bottom, max(geo.safeAreaInsets.bottom == 0 ? 16 : 8, 8))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(MenuPalette.ink)
            .ignoresSafeArea(edges: .top)
        }
        .preferredColorScheme(.dark)
        .sheet(item: $page) { selectedPage in
            switch selectedPage {
            case .settings: SettingsMenuView(musicEnabled: $musicEnabled, soundEnabled: $soundEnabled, language: $language, controlMode: $controlMode)
            case .controls: ControlsMenuView(controlMode: $controlMode)
            case .about: AboutMenuView()
            }
        }
        .sheet(isPresented: $showResourceGallery) { ResourceGalleryView() }
        .fullScreenCover(isPresented: $showMovementTest) { MovementSandboxView() }
        .alert(pendingAction ?? "Stranded", isPresented: Binding(get: { pendingAction != nil }, set: { if !$0 { pendingAction = nil } })) {
            Button("Открыть тестовый экран") { pendingAction = nil; showMovementTest = true }
            Button("Закрыть", role: .cancel) { pendingAction = nil }
        } message: {
            Text("Пункты главного меню уже оформлены для iOS, но игровая логика оригинальной Java-версии ещё не перенесена. Этот пункт пока открывает только тест управления, а не настоящую игру.")
        }
    }

    @ViewBuilder private var menuBackground: some View {
        if let image = bundledImage("mb") {
            Image(uiImage: image)
                .resizable()
                .interpolation(.high)
                .scaledToFill()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipped()
                .ignoresSafeArea()
        } else {
            MenuPalette.ink.ignoresSafeArea()
        }
    }

    private func menuButton(_ title: String, subtitle: String, prominent: Bool = false, disabled: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 13) {
                Rectangle().fill(prominent ? MenuPalette.gold : Color.white.opacity(disabled ? 0.12 : 0.35)).frame(width: 3)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(size: 15, weight: .heavy, design: .monospaced)).tracking(1.1)
                    Text(subtitle).font(.system(size: 10, weight: .regular)).foregroundStyle(.white.opacity(disabled ? 0.32 : 0.62))
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right").font(.system(size: 11, weight: .bold)).foregroundStyle(prominent ? MenuPalette.gold : .white.opacity(0.6))
            }
            .foregroundStyle(disabled ? .white.opacity(0.35) : MenuPalette.pale)
            .padding(.horizontal, 14)
            .frame(height: 58)
            .background(prominent ? Color.black.opacity(0.72) : Color.black.opacity(0.52))
            .overlay(Rectangle().stroke(prominent ? MenuPalette.gold.opacity(0.85) : .white.opacity(0.15), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(disabled)
    }
}

private struct SettingsMenuView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var musicEnabled: Bool
    @Binding var soundEnabled: Bool
    @Binding var language: String
    @Binding var controlMode: String
    var body: some View {
        NavigationStack {
            Form {
                Section("ЗВУК") {
                    Toggle("Музыка", isOn: $musicEnabled)
                    Toggle("Звуковые эффекты", isOn: $soundEnabled)
                    Text("Переключатели сохраняются на устройстве. Воспроизведение оригинальных MIDI-треков ещё требует отдельного аудиомодуля.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("ЯЗЫК") {
                    Picker("Язык интерфейса", selection: $language) {
                        Text("Русский").tag("Русский")
                        Text("English").tag("English")
                    }
                    Text("Сейчас доступен интерфейс меню на русском; английская локализация меню ещё не подключена.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("УПРАВЛЕНИЕ") {
                    Picker("Способ управления", selection: $controlMode) {
                        Text("Экранные кнопки").tag("Экранные кнопки")
                        Text("Жесты").tag("Жесты")
                    }
                }
            }
            .navigationTitle("Настройки")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
    }
}

private struct ControlsMenuView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var controlMode: String
    var body: some View {
        NavigationStack {
            List {
                Section("На iPhone") {
                    Label("Движение", systemImage: "arrow.left.arrow.right")
                    Text("В тестовой сцене используйте экранные стрелки. Перенос оригинальных действий и взаимодействий ещё не завершён.").font(.footnote).foregroundStyle(.secondary)
                    Label("Выбор и подтверждение", systemImage: "hand.tap")
                    Text("Кнопки меню нажимаются касанием. Игровые команды будут подключены при переносе логики Java ME.").font(.footnote).foregroundStyle(.secondary)
                }
                Section("Режим") {
                    Picker("Управление", selection: $controlMode) {
                        Text("Экранные кнопки").tag("Экранные кнопки")
                        Text("Жесты").tag("Жесты")
                    }
                }
            }
            .navigationTitle("Управление")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
    }
}

private struct AboutMenuView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    if let image = bundledImage("sp") {
                        Image(uiImage: image).resizable().interpolation(.none).scaledToFit().frame(maxHeight: 320).clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    Text("STRANDED").font(.system(size: 25, weight: .black, design: .serif)).tracking(4)
                    Text("Адаптация классической Java ME-версии для iOS.")
                        .multilineTextAlignment(.center)
                    Text("Оригинальные изображения, данные и музыка извлечены из JAR. Главное меню — нативный интерфейс SwiftUI. Полная игровая логика, сохранения и оригинальное аудио ещё в работе.")
                        .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }.padding(24)
            }
            .background(MenuPalette.ink)
            .navigationTitle("Об игре")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
    }
}

struct ResourceGalleryView: View {
    @Environment(\.dismiss) private var dismiss
    private let images = ["ch00a", "ch00b", "ch01", "ch02", "ch03", "ch04", "ch05", "ch06", "mb", "sp", "i"]
    private let columns = [GridItem(.flexible()), GridItem(.flexible())]
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(images, id: \.self) { name in
                        VStack(spacing: 7) {
                            if let image = bundledImage(name) {
                                Image(uiImage: image).resizable().interpolation(.none).aspectRatio(contentMode: .fit)
                                    .frame(maxWidth: .infinity).frame(height: 170).background(Color.white.opacity(0.05))
                                    .clipShape(RoundedRectangle(cornerRadius: 6))
                            } else {
                                RoundedRectangle(cornerRadius: 6).fill(.red.opacity(0.15)).frame(height: 170)
                                    .overlay(Text("Не найдено").foregroundStyle(.red))
                            }
                            Text(name + ".png").font(.system(size: 11, design: .monospaced)).foregroundStyle(.white.opacity(0.8))
                        }
                    }
                }.padding()
            }
            .background(MenuPalette.ink)
            .navigationTitle("Ресурсы игры")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Готово") { dismiss() } } }
        }.preferredColorScheme(.dark)
    }
}

private func bundledImage(_ name: String) -> UIImage? {
    let rootURL = Bundle.main.url(forResource: name, withExtension: "png")
    let resourcesURL = Bundle.main.url(forResource: name, withExtension: "png", subdirectory: "Resources")
    guard let url = rootURL ?? resourcesURL else { return nil }
    return UIImage(contentsOfFile: url.path)
}
